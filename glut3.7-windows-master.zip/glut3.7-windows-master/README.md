# glut3.7-windows
Facilitar o download dos arquivos para configuração no windows


Como configurar o OpenGL com o glut no visual studio:

(Em breve um link)
